package com.example.demo.Repository;
import com.example.demo.model.Hotel;

public interface HotelRepositorio extends Repositorio<Hotel, String>{
    
  
}
