package com.example.demo.Repository;
import com.example.demo.model.Huesped;

public interface HuespedRepositorio extends Repositorio<Huesped, String>{
    
}
